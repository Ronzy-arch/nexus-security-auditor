""" network_utils.py """
