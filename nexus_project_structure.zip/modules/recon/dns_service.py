""" dns_service.py """
