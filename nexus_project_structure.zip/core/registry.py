""" registry.py """
