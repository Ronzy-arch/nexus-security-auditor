""" test_registry.py """
